import React from "react";
import "../Styles/components/Spinner.scss";

const Spinner: React.FC = () => {
  return (
    <div className="spinner-wrapper">
      <div className="spinner" />
    </div>
  );
};

export default Spinner;

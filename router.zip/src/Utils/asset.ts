import LoginImage from '../assets/Images/png/introImage.png'
import milk from '../assets/Images/png/milk.png'

const asset: { [key: string]: string } = {
    LoginImage,milk
}

export default asset;
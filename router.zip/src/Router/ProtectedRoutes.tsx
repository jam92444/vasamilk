// routes/ProtectedRoute.tsx
import React, { type ReactNode } from "react";
import { Navigate } from "react-router-dom";
import { getDecryptedCookie } from "../Utils/cookies";

interface ProtectedRouteProps {
  children: ReactNode;
  onlyWhenLoggedOut?: boolean;
}

const ProtectedRoute: React.FC<ProtectedRouteProps> = ({
  children,
  onlyWhenLoggedOut = false,
}) => {
  const userToken = getDecryptedCookie("user_token");
  const loggedIn = !!userToken;

  if (onlyWhenLoggedOut && loggedIn) {
    const userType = userToken.user_type;
    return <Navigate to={userType === 1 ? "/admin-dashboard" : "/"} />;
  }

  return <>{children}</>;
};

export default ProtectedRoute;

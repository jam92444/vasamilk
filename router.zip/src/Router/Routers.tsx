import { createHashRouter } from "react-router-dom";
import { authRoutes } from "./authRoutes";
import { homeRoutes } from "./HomeRoutes";

const combinedRoutes = [...authRoutes, ...homeRoutes];

export const router = createHashRouter(combinedRoutes);

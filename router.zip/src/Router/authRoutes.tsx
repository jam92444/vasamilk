import { Outlet } from "react-router-dom";
import ProtectedRoute from "./ProtectedRoutes";
import Home from "../Screens/User/Home";
import Unauthorized from "../Screens/Auth/Unauthorized";
import Login from "../Screens/Auth/Login";
import ForgetPassword from "../Screens/Auth/ForgetPassword";
import OtpInput from "../Screens/Auth/OtpInput";
import ResetPassword from "../Screens/Auth/ResetPassword";
import AdminDashBoard from "../Screens/Admin/AdminDashBoard";

export const authRoutes = [
  {
    path: "/",
    element: <Home />,
  },
  {
    path: "/unauthorized",
    element: <Unauthorized />,
  },
  {
    path: "/",
    element: (
      <ProtectedRoute onlyWhenLoggedOut={true}>
        <Outlet />
      </ProtectedRoute>
    ),
    children: [
      { path: "login", element: <Login /> },
      { path: "forget-password", element: <ForgetPassword /> },
      { path: "otp-verfication", element: <OtpInput /> },
      { path: "reset-password", element: <ResetPassword /> },
    ],
  },
  {
    path: "/admin-dashboard",
    element: <AdminDashBoard />,
  },
];

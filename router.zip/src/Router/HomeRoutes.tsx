import PrivateRoute from "./PrivateRoutes";
import AdminDashBoard from "../Screens/Admin/AdminDashBoard";

export const homeRoutes = [
  {
    path: "/admin-dashboard",
    element: <PrivateRoute allowedRoles={["admin"]} />,
    children: [
      { path: "", element: <AdminDashBoard /> },
      // other admin routes...
    ],
  },
  {
    path: "/vendor/dashboard",
    element: <PrivateRoute allowedRoles={["vendor"]} />,
    children: [
      // vendor routes
    ],
  },
  {
    path: "",
    element: <PrivateRoute allowedRoles={["user"]} />,
    children: [
      // user routes
    ],
  },
];

import React, { type ReactNode } from "react";
import { Navigate, Outlet } from "react-router-dom";
import { getDecryptedCookie } from "../Utils/cookies";

interface PrivateRouteProps {
  allowedRoles: string[]; // e.g. ["admin", "vendor", "user"]
  redirectUnauthorizedTo?: string;
  redirectUnauthenticatedTo?: string;
  children?: ReactNode;
}

const USER_TYPE_MAP: Record<number, string> = {
  1: "admin",
  2: "vendor",
  3: "user",
};

const PrivateRoute: React.FC<PrivateRouteProps> = ({
  allowedRoles,
  redirectUnauthorizedTo = "/",
  redirectUnauthenticatedTo = "/login",
  children,
}) => {
  let user_type: number | null = null;

  try {
    const cookie = getDecryptedCookie("user_token");
    if (cookie && typeof cookie === "object" && "user_type" in cookie) {
      user_type = cookie.user_type;
    }
  } catch {
    user_type = null;
  }

  if (!user_type) {
    return <Navigate to={redirectUnauthenticatedTo} replace />;
  }

  const role = USER_TYPE_MAP[user_type];

  if (!role || !allowedRoles.includes(role)) {
    return <Navigate to={redirectUnauthorizedTo} replace />;
  }

  return children ? <>{children}</> : <Outlet />;
};

export default PrivateRoute;

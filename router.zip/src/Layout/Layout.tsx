import React, { useState } from "react";
import { PieChartOutlined, UserOutlined } from "@ant-design/icons";
import type { MenuProps } from "antd";
import { Layout, Menu, Grid } from "antd";
import "../Styles/main.scss";

const { Header, Content, Sider } = Layout;
const { useBreakpoint } = Grid;

type MenuItem = Required<MenuProps>["items"][number];

interface LayoutProps {
  children: React.ReactNode;
}

function getItem(
  label: React.ReactNode,
  key: React.Key,
  icon?: React.ReactNode,
  children?: MenuItem[]
): MenuItem {
  return {
    key,
    icon,
    children,
    label,
  } as MenuItem;
}

const menuItems: MenuItem[] = [
  getItem("Dashboard", "1", <PieChartOutlined />),
  getItem("Customer Management", "2", <UserOutlined />),
];

const MainLayout: React.FC<LayoutProps> = ({ children }) => {
  const [collapsed, setCollapsed] = useState(false);
  const screens = useBreakpoint();

  return (
    <Layout className="main-layout">
      <Sider
        collapsible
        collapsed={collapsed}
        onCollapse={setCollapsed}
        breakpoint="md"
        collapsedWidth={screens.xs ? 0 : 80}
        className="main-layout__sider"
      >
        <div className="main-layout__logo">VM</div>
        <Menu
          theme="dark"
          mode="inline"
          defaultSelectedKeys={["1"]}
          items={menuItems}
          className="main-layout__menu"
        />
      </Sider>

      <Layout>
        <Header className="main-layout__header">
          <h1 className="main-layout__title">VASAMILK DASHBOARD</h1>
        </Header>
        <Content className="main-layout__content">
          <div className="main-layout__content-container">{children}</div>
        </Content>
      </Layout>
    </Layout>
  );
};

export default MainLayout;

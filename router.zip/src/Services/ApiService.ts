import axiosInstance from "./Axios";

export const loginUser = (payload: any) => {
  return axiosInstance.post("/milk-api/auth/login", payload);
};

export const forgetPassword = (payload: any) => {
  return axiosInstance.post("/milk-api/auth/forgot-password", payload);
};

export const verifyOTP = (payload: any) => {
  return axiosInstance.post("/milk-api/auth/otp-verification", payload);
};

export const resendOTP = (payload: any) => {
  return axiosInstance.post("/milk-api/auth/resend-otp", payload);
};
export const resetPassword = (payload: any) => {
  return axiosInstance.post("/milk-api/auth/reset-password", payload);
};

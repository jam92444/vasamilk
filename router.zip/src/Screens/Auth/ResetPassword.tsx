import React from "react";
import * as Yup from "yup";
import { useFormik } from "formik";
import { toast } from "react-toastify";
import { resetPassword } from "../../Services/ApiService";
import CustomInput from "../../Components/UI/CustomInput";
import CustomButton from "../../Components/UI/CustomButton";
import "../../Styles/pages/_login.scss";
import { Navigate, useLocation, useNavigate } from "react-router-dom";
import { getDecryptedCookie, clearCookie } from "../../Utils/cookies";
import { siteName } from "../../App";
import { useAuth } from "../../Context/AuthContext";

//schema for strong password
const resetPasswordSchema = Yup.object().shape({
  password: Yup.string()
    .required("Password is required")
    .min(
      8,
      "Password Must include letter, number, special char at least 8 characters long"
    )
    .matches(/[A-Z]/, "Must include at least one uppercase letter")
    .matches(/[a-z]/, "Must include at least one lowercase letter")
    .matches(/[0-9]/, "Must include at least one number")
    .matches(
      /[!@#$%^&*(),.?":{}|<>]/,
      "Must include at least one special character"
    ),
});

// Types
interface ResetTypes {
  password: string;
}

// Initial values
const initialValues: ResetTypes = {
  password: "",
};

const ResetPassword: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { isAuthenticated, userDetails } = useAuth();

  if (isAuthenticated) {
    if (userDetails?.user_type === 1) {
      return <Navigate to="/admin-dashboard" />;
    } else {
      return <Navigate to="/" />;
    }
  }
  if (location.state?.from !== "otp-verification") {
    return <Navigate to="/login" />;
  }

  const handleResetPassword = (values: ResetTypes) => {
    const reset_key = getDecryptedCookie("reset_key");
    if (!reset_key) {
      toast.error("Reset session expired. Please request a new OTP.");
      navigate("/forget-password");
      return;
    }
    console.log("reset_key in Resend  Password ", reset_key);
    const formData = new FormData();
    formData.append("reset_key", reset_key);
    formData.append("new_password", values.password);

    resetPassword(formData)
      .then((res) => {
        if (res.data.status === 0) {
          toast.error(res.data.msg);
        } else {
          toast.success(res.data.msg || "Password reset successful!");
          clearCookie("reset_key");
          navigate("/");
        }
      })
      .catch((error: any) => {
        console.error("Reset error:", error.response?.data || error.message);
        toast.error("Failed to reset password. Please try again.");
      });
  };

  const formik = useFormik<ResetTypes>({
    initialValues,
    validationSchema: resetPasswordSchema,
    onSubmit: handleResetPassword,
  });

  const { values, errors, touched, handleChange, handleSubmit } = formik;

  return (
    <div className="login-page">
      <div className="login-section">
        <p>{siteName}</p>
        <h1>Reset Password</h1>

        <form onSubmit={handleSubmit}>
          <CustomInput
            label="New Password"
            name="password"
            type="password"
            placeholder="Enter your new strong password"
            value={values.password}
            onChange={handleChange}
          >
            {touched.password && errors.password && (
              <div className="error-text">{errors.password}</div>
            )}
            <span>Must include 1chr 1 number 1 speciaal chat</span>
          </CustomInput>

          <CustomButton htmlType="submit" text="Reset Password" />
        </form>
      </div>
    </div>
  );
};

export default ResetPassword;

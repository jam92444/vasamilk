import MainLayout from "../../Layout/Layout";

const AdminDashBoard = () => {
  return (
    <MainLayout>
      <p>Hello</p>
    </MainLayout>
  );
};

export default AdminDashBoard;

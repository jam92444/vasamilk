import React from "react";
// import MainLayout from "../../Layout/Layout";
const Home: React.FC = () => {
  return <div>Home</div>;
};

export default Home;
